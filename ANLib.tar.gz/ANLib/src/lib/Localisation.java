/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.util.ResourceBundle;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class Localisation {

    // Private Stuff
    private final ResourceBundle messages;

    public Localisation(String resource) {
        messages = ResourceBundle.getBundle(resource);
    }

    public String getString(String key) {
        if (key == null) {
            return "";
        }
        try {
            return messages.getString(key);
        } catch (Exception ex) {
        }
        return key;
    }

    public String[] getStrings(String... keys) {

        String[] result = new String[keys.length];
        int i = 0;
        for (String key : keys) {
            result[i++] = messages.getString(key);
        }
        return result;
    }
}
