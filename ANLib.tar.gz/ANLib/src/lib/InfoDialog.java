/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.Timer;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class InfoDialog extends javax.swing.JDialog {

    /**
     * A return status code - returned if Cancel button has been pressed
     */
    public static final int CANCEL = 0;
    /**
     * A return status code - returned if OK button has been pressed
     */
    public static final int OK = 1;
    private final int height = 0;
    private final int width = 0;
    private Color fg = null;
    private final Frame parent;
    private String strButtCancel = "Cancel";
    private String strButtClose = "Close";
    private String strButtCont = "Continue";
    private Timer tmrAutoClose;

    /**
     * Creates new InfoDialog, for parent frame with modality modal
     *
     * @param parent
     */
    public InfoDialog(Frame parent) {
        super(parent, true);
        this.parent = parent;
        initComponents();
        jCheckDisableNotify.setVisible(false);
        fg = jTextInfo.getForeground();
        tmrAutoClose = new Timer(10000, new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tmrAutoClose.stop();
                doClose(CANCEL);
            }
        });
    }

    /**
     * Convenience methods
     *
     * @param title
     */
    public void createInfo(String title) {
        createInfo(title, null);
    }

    /**
     *
     * @param title
     * @param info
     */
    public void createInfo(String title, String info) {
        setModal(true);
        setCancelVisible(false);
        setAckText(strButtClose);
        jTextInfo.setForeground(fg);
        jTextInfo.setText("");
        jLabelImage.setText(title);
        if (info != null) {
            jTextInfo.setText(info);
        }
        setLocationRelativeTo(parent);
    }

    /**
     * Set big title text
     *
     * @param text
     */
    public void setBigTitle(String text) {
        jLabelImage.setText(text);
    }

    /**
     *
     * @param title
     */
    public void createWarn(String title) {
        createWarn(title, null);
    }

    /**
     *
     * @param title
     * @param info
     */
    public void createWarn(String title, String info) {
        setModal(true);
        setCancelVisible(true);
        setAckText(strButtCont);
        setCancelText(strButtCancel);
        jTextInfo.setForeground(fg);
        jTextInfo.setText("");
        jLabelImage.setText(title);
        if (info != null) {
            jTextInfo.setText(info);
        }
        setLocationRelativeTo(parent);
    }

    /**
     *
     * @param title
     */
    public void createError(String title) {
        createError(title, null);
    }

    /**
     *
     * @param title
     * @param info
     */
    public void createError(String title, String info) {
        setModal(true);
        setCancelVisible(false);
        setAckText(strButtClose);
        jTextInfo.setForeground(fg);
        jTextInfo.setText("");
        jLabelImage.setText(title);
        if (info != null) {
            jTextInfo.setText(info);
        }
        setLocationRelativeTo(parent);
    }

    public void setButtonsText(String cancel, String close, String cont) {
        strButtCancel = cancel;
        strButtClose = close;
        strButtCont = cont;
    }

    /**
     * Enable/Disable Autoscrolling
     *
     * @param enabled
     */
    public void setAutoScrollEnabled(boolean enabled) {
        jTextInfo.setAutoscrolls(enabled);
    }

    /**
     * Append text to the information area, Scrolling should be enabled
     *
     * @param text
     */
    public void appendInfoText(String text) {
        jTextInfo.append(text);
        jTextInfo.setCaretPosition(jTextInfo.getText().length());
    }

    /**
     * Append text to the title area
     *
     * @param text
     */
    public void appendTitleText(String text) {
        jLabelImage.setText(jLabelImage.getText() + text);
    }

    /**
     * Set whether the forms checkbox is enabled
     *
     * @param enabled
     */
    public void setCheckBoxEnabled(boolean enabled) {
        jCheckDisableNotify.setVisible(enabled);
    }

    /**
     * Test to see if checkbox is selected
     *
     * @return boolean True if selected
     */
    public boolean isCheckBoxSelected() {
        return jCheckDisableNotify.isSelected();
    }

    /**
     * Modify form height
     *
     * @param pixels
     */
    public void addHeight(int pixels) {
        this.setSize(width, height + pixels);
        this.pack();
    }

    /**
     * Modify form width
     *
     * @param pixels
     */
    public void addWidth(int pixels) {
        this.setSize(width + pixels, height);
        this.pack();
    }

    /**
     * Set the form auto close period in milliseconds
     *
     * @param millis
     */
    public final void setAutoClose(int millis) {
        tmrAutoClose.setDelay(millis);
        tmrAutoClose.setInitialDelay(millis);
        tmrAutoClose.start();
    }

    public JTextArea getTextArea() {
        return jTextInfo;
    }

    /**
     * @return the return status of this dialog - one of RET_OK or RET_CANCEL
     */
    public int getReturnStatus() {
        return returnStatus;
    }

    public String getInfoTitle() {
        return jLabelImage.getText();
    }

    /**
     * Set dialog message body
     *
     * @param text
     */
    public void setInfoText(String text) {
        jTextInfo.setText(text);
    }

    /**
     * Set dialog message body, and font colour
     *
     * @param text
     * @param fgcolor
     */
    public void setInfoText(String text, Color fgcolor) {
        jTextInfo.setForeground(fgcolor);
        jTextInfo.setText(text);
    }

    /**
     * Set whether Cancel button is enabled
     *
     * @param enabled
     */
    public void setCancelEnabled(boolean enabled) {
        jButtonCancel.setEnabled(enabled);
    }

    /**
     * Set whether Cancel button is visible
     *
     * @param visible
     */
    public void setCancelVisible(boolean visible) {
        jButtonCancel.setVisible(visible);
    }

    /**
     * Set whether Ok button is enabled
     *
     * @param enabled
     */
    public void setAckEnabled(boolean enabled) {
        jButtonAck.setEnabled(enabled);
    }

    /**
     * Set whether OK button is visible
     *
     * @param visible
     */
    public void setAckVisible(boolean visible) {
        jButtonAck.setVisible(visible);
    }

    /**
     * Set the text that appears on the Cancel buttton
     *
     * @param text
     */
    public void setCancelText(String text) {
        jButtonCancel.setText(text);
    }

    /**
     * Set the text that appears on the OK button
     *
     * @param text
     */
    public void setAckText(String text) {
        jButtonAck.setText(text);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelMain = new javax.swing.JPanel();
        jLabelImage = new javax.swing.JLabel();
        jButtonCancel = new javax.swing.JButton();
        jCheckDisableNotify = new javax.swing.JCheckBox();
        jButtonAck = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextInfo = new javax.swing.JTextArea();

        setMinimumSize(new java.awt.Dimension(410, 165));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });

        jPanelMain.setOpaque(false);

        jLabelImage.setFont(jLabelImage.getFont().deriveFont(jLabelImage.getFont().getStyle() | java.awt.Font.BOLD, jLabelImage.getFont().getSize()+4));
        jLabelImage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelImage.setText("Information");
        jLabelImage.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabelImage.setIconTextGap(10);

        jButtonCancel.setText("Cancel");
        jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelActionPerformed(evt);
            }
        });

        jCheckDisableNotify.setText("Disable this notification.");

        jButtonAck.setText("Continue");
        jButtonAck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAckActionPerformed(evt);
            }
        });

        jTextInfo.setEditable(false);
        jTextInfo.setColumns(20);
        jTextInfo.setLineWrap(true);
        jTextInfo.setRows(5);
        jTextInfo.setWrapStyleWord(true);
        jScrollPane2.setViewportView(jTextInfo);

        javax.swing.GroupLayout jPanelMainLayout = new javax.swing.GroupLayout(jPanelMain);
        jPanelMain.setLayout(jPanelMainLayout);
        jPanelMainLayout.setHorizontalGroup(
            jPanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabelImage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanelMainLayout.createSequentialGroup()
                .addComponent(jCheckDisableNotify)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonCancel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonAck))
            .addComponent(jScrollPane2)
        );
        jPanelMainLayout.setVerticalGroup(
            jPanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelMainLayout.createSequentialGroup()
                .addComponent(jLabelImage)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 283, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelMainLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckDisableNotify)
                    .addComponent(jButtonAck)
                    .addComponent(jButtonCancel)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelMain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelMain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void jButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelActionPerformed
        doClose(CANCEL);
    }//GEN-LAST:event_jButtonCancelActionPerformed

    /**
     * Closes the dialog
     */
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        doClose(CANCEL);
    }//GEN-LAST:event_closeDialog

    private void jButtonAckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAckActionPerformed
        doClose(OK);
    }//GEN-LAST:event_jButtonAckActionPerformed

    private void doClose(int retStatus) {
        returnStatus = retStatus;
        setVisible(false);
        dispose();
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAck;
    private javax.swing.JButton jButtonCancel;
    private javax.swing.JCheckBox jCheckDisableNotify;
    private javax.swing.JLabel jLabelImage;
    private javax.swing.JPanel jPanelMain;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextInfo;
    // End of variables declaration//GEN-END:variables
    private int returnStatus = CANCEL;
}
