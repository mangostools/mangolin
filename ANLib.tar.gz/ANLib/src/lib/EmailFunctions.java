/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import com.sun.mail.smtp.SMTPTransport;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class EmailFunctions {

    private static final Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    private String mailerinfo = "EmailFunctions";
    private String mailto = null;
    private String mailfrom = null;
    private String mailsubject = null;
    private String mailcc = null;
    private String mailbcc = null;
    private String mailbody = null;
    private String hostname = null;
    private String username = null;
    private String password = null;
    private boolean debug = false;
    private boolean auth = false;
    private File attachment = null;

    /**
     * Class constructor
     */
    public EmailFunctions() {
    }

    /**
     * Set whether debug is enabled or not
     *
     * @param enabled
     */
    public void setDebug(boolean enabled) {
        debug = enabled;
    }

    /**
     * Set mailer info
     *
     * @param text
     */
    public void setMailerInfo(String text) {
        mailerinfo = text;
    }

    /**
     * Set hostname
     *
     * @param host
     */
    public void setHost(String host) {
        hostname = host;
    }

    /**
     * Set authentification info
     *
     * @param user
     * @param pass
     */
    public void setAuthInfo(String user, String pass) {
        username = user;
        password = pass;
        auth = true;
    }

    /**
     * Set post information
     *
     * @param to
     * @param from
     * @param subject
     */
    public void setPostInfo(String to, String from, String subject) {
        mailto = to;
        mailfrom = from;
        mailsubject = subject;
    }

    /**
     * Set additional post info
     *
     * @param cc
     * @param bcc
     */
    public void setOtherPostInfo(String cc, String bcc) {
        mailcc = cc;
        mailbcc = bcc;
    }

    /**
     * Set email message body
     *
     * @param message
     */
    public void setEmailMessage(String message) {
        mailbody = message;
    }

    /**
     * Set any attachment files
     *
     * @param afile
     */
    public void setAttachment(File afile) {
        attachment = afile;
    }

    /**
     * Send mail
     *
     * @return String
     */
    public String sendSmtpMail() {

        String result;
        Properties props = System.getProperties();
        if (hostname != null) {
            props.put("mail." + "smtp" + ".host", hostname);
        }
        if (auth) {
            props.put("mail." + "smtp" + ".auth", "true");
        }

        // Lets get our mail session
        Session session = Session.getInstance(props, null);
        session.setDebug(debug);

        // We build our message here
        Message mimeMessage = new MimeMessage(session);
        try {
            if (mailfrom != null) {
                mimeMessage.setFrom(new InternetAddress(mailfrom));
            } else {
                mimeMessage.setFrom();
            }
            mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mailto, false));
            if (mailcc != null) {
                mimeMessage.setRecipients(Message.RecipientType.CC, InternetAddress.parse(mailcc, false));
            }
            if (mailbcc != null) {
                mimeMessage.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(mailbcc, false));
            }
            mimeMessage.setSubject(mailsubject);
            if (attachment != null) {
                // Attach the specified file.
                // We need a multipart message to hold the attachment.
                MimeMultipart mimeMultipart = new MimeMultipart();
                MimeBodyPart part1 = new MimeBodyPart();
                MimeBodyPart part2 = new MimeBodyPart();
                part1.setText(mailbody);
                part2.attachFile(attachment);
                mimeMultipart.addBodyPart(part1);
                mimeMultipart.addBodyPart(part2);
                mimeMessage.setContent(mimeMultipart);
            } else {
                mimeMessage.setText(mailbody);
            }
            mimeMessage.setHeader("X-Mailer", mailerinfo);
            mimeMessage.setSentDate(new Date());

            SMTPTransport transport = (SMTPTransport) session.getTransport("smtp");
            try {
                if (auth) {
                    transport.connect(hostname, username, password);
                } else {
                    transport.connect();
                }
                transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());
            } finally {
                result = transport.getLastServerResponse();
                transport.close();
            }
            return result;
        } catch (MessagingException | IOException ex) {
            logger.throwing(this.getClass().getName(), "sendSmtpMail()", ex);
            return null;
        }
    }
}
