/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class SimpleINI {

    private static final Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    private HashMap<String, HashMap<String, String>> allGroups;
    private HashMap<String, String> currentGroup;
    private final String fileName;
    private final SimpleFileIO ourFileIO = new SimpleFileIO();
    private final SimpleDateFormat sdf = new SimpleDateFormat();
    private final ArrayList<String> changes = new ArrayList<>();

    /**
     * Creates a new instance of SimpleINI
     *
     * @param filepath The path to the ini file
     * @param filename The ini filename
     */
    public SimpleINI(String filepath, String filename) {
        fileName = filename;
        allGroups = new HashMap<>();
        ourFileIO.setDefaultFilePath(filepath);
        ourFileIO.createFolder(filepath);
        allGroups = load();
    }

    /**
     * Clears all items from the current group
     */
    public void clearGroupItems() {
        currentGroup.clear();
    }

    /**
     * Removes specified group
     *
     * @param aGroup
     */
    public void removeGroup(String aGroup) {
        allGroups.remove(aGroup);
    }

    public boolean deleteINI() {
        return ourFileIO.getReadFile().delete();
    }

    public void reset() {
        deleteINI();
        clearGroupItems();
        allGroups.clear();
        changes.clear();
    }

    /**
     * @return Returns true if settings have changed
     */
    public boolean isChanged() {
        return !changes.isEmpty();
    }

    public ArrayList<String> getChangeList() {
        return new ArrayList<>(changes);
    }

    /**
     * @return Returns the current filepath
     */
    public String getFilePath() {
        return ourFileIO.getDefaultFilePath();
    }

    /**
     * Sets the current ini group
     *
     * @param aGroup The name of the group
     * @return true if succesful
     */
    public boolean setGroup(String aGroup) {
        currentGroup = allGroups.get(aGroup);
        if (currentGroup == null) {
            currentGroup = new HashMap<>();
            allGroups.put(aGroup, currentGroup);
            return true;
        }
        return false;
    }

    /**
     * Sets a value within the current group with a specified key
     *
     * @param aKey The key
     * @param aValue The value to be stored
     */
    public void setValue(String aKey, Object aValue) {
        if (currentGroup == null) {
            logger.log(Level.INFO, "setValue {0},{1}", new Object[]{aKey, aValue});
            return;
        }

        // Check for a value change
        if (currentGroup.get(aKey) == aValue) {
            return;
        }

        String cValue = currentGroup.get(aKey);
        if (cValue == null) {
            currentGroup.put(aKey, aValue.toString());
            changes.add(aKey);
            return;
        }

        if (aValue instanceof String) {
            if (((String) cValue).contentEquals((String) aValue)) {
                return;
            }
            changes.add(aKey);
            currentGroup.put(aKey, (String) aValue);
            return;
        }

        if (aValue instanceof Integer) {
            try {
                if (Integer.parseInt(cValue) == (Integer) aValue) {
                    return;
                }
            } catch (Exception ex) {
            }
            changes.add(aKey);
            currentGroup.put(aKey, ((Integer) aValue).toString());
            return;
        }

        if (aValue instanceof Long) {
            try {
                if (Long.parseLong(cValue) == (Long) aValue) {
                    return;
                }
            } catch (Exception ex) {
            }
            changes.add(aKey);
            currentGroup.put(aKey, ((Long) aValue).toString());
            return;
        }

        if (aValue instanceof Double) {
            try {
                if (Double.parseDouble(cValue) == (Double) aValue) {
                    return;
                }
            } catch (Exception ex) {
            }
            changes.add(aKey);
            currentGroup.put(aKey, ((Double) aValue).toString());
            return;
        }

        if (aValue instanceof Boolean) {
            try {
                if (Boolean.parseBoolean(cValue) == (Boolean) aValue) {
                    return;
                }
            } catch (Exception ex) {
            }
            changes.add(aKey);
            currentGroup.put(aKey, ((Boolean) aValue).toString());
            return;
        }

        if (aValue instanceof Date) {
            currentGroup.put(aKey, ((Date) aValue).toString());
            changes.add(aKey);
        }
    }

    /**
     * Sets a value within the current group with a specified key
     *
     * @param aKey The key
     * @param aValue The time to be stored
     */
    public void setTime(String aKey, Date aValue) {

        String time;
        sdf.applyPattern("HH:mm:ss");
        time = sdf.format(aValue);
        setValue(aKey, time);
    }

    public Date getTime(String aKey, String defValue) {

        Date date;
        sdf.applyPattern("HH:mm:ss");
        try {
            date = sdf.parse(getStringValue(aKey));
            return date;
        } catch (Exception ex) {
        }
        try {
            date = sdf.parse(defValue);
            return date;
        } catch (Exception ex) {
        }
        return null;
    }

    /**
     * Gets a value within the specified group with a specific key and a default
     * value
     *
     * @return Returns a value as a string
     * @param aGroup The group
     * @param aKey The key
     * @param defValue The default value if value doesnt exist
     */
    @Deprecated
    public String getValue(String aGroup, String aKey, String defValue) {
        if (setGroup(aGroup)) {
            setValue(aKey, defValue);
            changes.remove(aKey);
        }
        return getValue(aKey, defValue);
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @param defValue
     * @return Returns a value as a string
     * @param aKey The key
     */
    @Deprecated
    public String getValue(String aKey, String defValue) {
        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            setValue(aKey, defValue);
            changes.remove(aKey);
            return defValue;
        }
        return value;
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @return Returns a value as a string
     * @param aGroup The group
     * @param aKey The key
     * @param defValue The default value
     */
    public String getStringValue(String aGroup, String aKey, String defValue) {
        if (setGroup(aGroup)) {
            setValue(aKey, defValue);
            changes.remove(aKey);
        }
        return getStringValue(aKey, defValue);
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @return Returns a value as a string
     * @param aKey The key
     * @param defValue The default value
     */
    public String getStringValue(String aKey, String defValue) {
        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            setValue(aKey, defValue);
            changes.remove(aKey);
            return defValue;
        }
        return value;
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @param defValue
     * @return Returns a value as an Integer
     * @param aKey The key
     */
    public Integer getIntegerValue(String aKey, Integer defValue) {
        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            setValue(aKey, defValue);
            changes.remove(aKey);
            return defValue;
        }
        try {
            return new Integer(value);
        } catch (Exception ex) {
            return defValue;
        }
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @return Returns a value as an Integer
     * @param aKey The key
     */
    public Integer getIntegerValue(String aKey) {
        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            return null;
        }
        return new Integer(value);
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @param defValue
     * @return Returns a value as a Double
     * @param aKey The key
     */
    public Double getDoubleValue(String aKey, Double defValue) {
        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            setValue(aKey, defValue);
            changes.remove(aKey);
            return defValue;
        }
        return new Double(value);
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @return Returns a value as a Double
     * @param aKey The key
     */
    public Double getDoubleValue(String aKey) {
        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            return null;
        }
        return new Double(value);
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @param defValue
     * @return Returns a value as a Long
     * @param aKey The key
     */
    public Long getLongValue(String aKey, Long defValue) {
        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            setValue(aKey, defValue);
            changes.remove(aKey);
            return defValue;
        }
        return new Long(value);
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @return Returns a value as a Long
     * @param aKey The key
     */
    public Long getLongValue(String aKey) {
        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            return null;
        }
        return new Long(value);
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @param defValue
     * @return Returns a value as boolean
     * @param aKey The key
     */
    public Boolean getBoolValue(String aKey, boolean defValue) {
        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            setValue(aKey, defValue);
            changes.remove(aKey);
            return defValue;
        }
        return (value.compareTo("true") == 0);
    }

    /**
     * Gets a value within the current group with a specific key and a default
     * value
     *
     * @return Returns a value as boolean
     * @param aKey The key
     */
    public Boolean getBoolValue(String aKey) {

        String value = getStringValue(aKey);
        if (value == null || value.isEmpty()) {
            return null;
        }
        return (value.compareTo("true") == 0);
    }

    /**
     * Gets a value within the current group with a specific key
     *
     * @return Returns a value as a string
     * @param aKey The key
     */
    public String getStringValue(String aKey) {
        if (currentGroup == null || currentGroup.isEmpty()) {
            return null;
        }
        return currentGroup.get(aKey);
    }

    /**
     * Saves data to the ini file
     */
    public void save() {

        String groupName;
        String key;
        String value;
        HashMap settings;

        changes.clear();
        ourFileIO.setWriteFilename(fileName);
        ourFileIO.openBufferedWrite();
        for (Iterator groupK = allGroups.keySet().iterator(); groupK.hasNext();) {
            groupName = (String) groupK.next();
            ourFileIO.writeToFile("[" + groupName + "]", 1);
            settings = allGroups.get(groupName);
            for (Iterator itemK = settings.keySet().iterator(); itemK.hasNext();) {
                key = (String) itemK.next();
                value = (String) settings.get(key);
                ourFileIO.writeToFile(key + "=" + value, 1);
            }
            ourFileIO.writeToFile("", 1);
        }
        ourFileIO.closeBufferedWrite();
    }

    /**
     * Loads data from ini file
     *
     * @return Returns hashtable with data
     */
    private HashMap<String, HashMap<String, String>> load() {

        HashMap<String, HashMap<String, String>> newGroups;
        HashMap<String, String> settings;
        String groupName;
        String key;
        String value;
        String read;
        int begidx, endidx;

        ourFileIO.setReadFilename(fileName);
        if (ourFileIO.openBufferedRead() == null) {
            return new HashMap<>();
        }
        newGroups = new HashMap<>();
        settings = new HashMap<>();
        groupName = "";
        try {
            while (true) {
                read = ourFileIO.readFromFile();
                if (read == null) {
                    break;
                }
                read = read.trim();
                begidx = read.indexOf("[");
                endidx = read.lastIndexOf("]");
                if (begidx != -1 && endidx != -1) {
                    if (settings.size() > 0) {
                        newGroups.put(groupName, settings);
                    }
                    groupName = read.substring(begidx + 1, endidx);
                    settings = new HashMap<>();
                    read = ourFileIO.readFromFile();
                    if (read == null) {
                        break;
                    }
                }
                begidx = read.indexOf("=");
                if (begidx != -1) {
                    key = read.substring(0, begidx).trim();
                    value = read.substring(begidx + 1).trim();
                    settings.put(key, value);
                }
            }
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "load()", ex);
        }
        newGroups.put(groupName, settings);
        ourFileIO.closeBufferedRead();
        return newGroups;
    }
}
