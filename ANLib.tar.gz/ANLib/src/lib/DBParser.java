/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class DBParser {

    private static final Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    private Hashtable<String, String> hashClientValues = null;
    private Hashtable<String, String> hashCompanyValues = null;
    private String premark = null;
    private String postmark = null;
    private List<String> liDateFormats = null;
    private List<String> liDateExamples = null;
    private SimpleDateFormat sdf = null;
    private Date dateExample = null;
    private Calendar calendar = null;

    /**
     * Class constructor
     */
    public DBParser() {

        calendar = Calendar.getInstance();
        hashClientValues = new Hashtable<>(10);
        hashCompanyValues = new Hashtable<>(10);
        premark = "<";
        postmark = ">";
        liDateFormats = new ArrayList<>();
        liDateExamples = new ArrayList<>();
        sdf = new SimpleDateFormat();
        setExampleDate("01/02/2007");
        addDateFormat("E, MMMM d, yyyy");
        addDateFormat("EEEE, MMMM d, yyyy");
        addDateFormat("E, MMM d, yyyy");
        addDateFormat("EEEE, MMM d, yyyy");
        addDateFormat("d MMM yyyy");
        addDateFormat("d MMMM yyyy");
        addDateFormat("dd/MM/yyyy ");
        addDateFormat("MM/dd/yyyy");
        addDateFormat("dd-MM-yyyy ");
        addDateFormat("MM-dd-yyyy");
        addDateFormat("MMM");
        addDateFormat("MMMM");
        addDateFormat("yyyy");
        addDateFormat("MMM yyyy");
        addDateFormat("MMMM yyyy");
    }

    /**
     * Add a date format string to parser
     *
     * @param pattern
     */
    private void addDateFormat(String pattern) {
        sdf.applyPattern(pattern);
        liDateFormats.add(pattern);
        liDateExamples.add(sdf.format(dateExample));
    }

    /**
     * Sets an example date provided as valid date in string format
     *
     * @param datestring
     */
    public void setExampleDate(String datestring) {
        try {
            sdf.applyPattern("dd/MM/yyyy");
            dateExample = sdf.parse(datestring);
        } catch (ParseException ex) {
            logger.throwing(this.getClass().getName(), "setExampleDate(" + datestring + ")", ex);
        }
    }

    /**
     * Get all the available date formats as a list of strings
     *
     * @return String[]
     */
    public String[] getDateFormats() {
        return liDateFormats.toArray(new String[liDateFormats.size()]);
    }

    /**
     * Get all the available date examples as a list of strings
     *
     * @return String[]
     */
    public String[] getDateExamples() {
        return liDateExamples.toArray(new String[liDateExamples.size()]);
    }

    /**
     * Clear all client fields
     */
    public void clearClientFields() {
        hashClientValues.clear();
    }

    /**
     * Clear all company fields
     */
    public void clearCompanyFields() {
        hashCompanyValues.clear();
    }

    /**
     * Add a client field with key.value
     *
     * @param key
     * @param value
     */
    public void addClientField(String key, String value) {
        try {
            hashClientValues.put(key, value);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "setClientField(" + key + "," + value + ")", ex);
        }
    }

    /**
     * Add a company field with key.value
     *
     * @param key
     * @param value
     */
    public void addCompanyField(String key, String value) {
        try {
            hashCompanyValues.put(key, value);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "setCompanyField(" + key + "," + value + ")", ex);
        }
    }

    /**
     * Get an enumeration of all client keys
     *
     * @return Enumeration
     */
    public Enumeration getClientKeys() {
        return hashClientValues.keys();
    }

    /**
     * Get an enumeration of all company keys
     *
     * @return Enumeration
     */
    public Enumeration getCompanyKeys() {
        return hashCompanyValues.keys();
    }

    /**
     * Get field pattern for a given key
     *
     * @param key
     * @return String
     */
    public String getFieldPattern(String key) {
        return premark + key + postmark;
    }

    /**
     * Get a client value for a given key
     *
     * @param key
     * @return String
     */
    public String getClientValue(String key) {
        return hashClientValues.get(key);
    }

    /**
     * Get a company value for a given key
     *
     * @param key
     * @return String
     */
    public String getCompanyValue(String key) {
        return hashCompanyValues.get(key);
    }

    /**
     * Set pre mark delimeter
     *
     * @param text
     */
    public void setPreMark(String text) {
        premark = text;
    }

    /**
     * Set post mark delimeter
     *
     * @param text
     */
    public void setPostMark(String text) {
        postmark = text;
    }

    /**
     * Parse the given text
     *
     * @param text
     * @return String
     */
    public String parseText(String text) {
        int s;
        int e;
        String key;
        String data;

        while (true) {
            s = text.indexOf(premark) + premark.length();
            if (s == 1) {
                break;
            }
            e = text.indexOf(postmark, s);
            if (e == -1) {
                break;
            }
            key = text.substring(s, e);
            data = hashClientValues.get(key);
            // If data is null then try the company info
            if (data == null) {
                data = hashCompanyValues.get(key);
            }
            // If data is still null then we probably have a date field
            if (data == null) {
                data = parseDate(key);
            }
            text = text.replace(getFieldPattern(key), data);
        }
        return text;
    }

    /**
     * Parse a datestring
     *
     * @param datestring
     * @return String
     */
    private String parseDate(String datestring) {

        int day = 0;
        int month = 0;
        int year = 0;
        int format;

        int idx = datestring.indexOf(',');
        try {
            format = Integer.parseInt(datestring.substring(idx + 1));
        } catch (NumberFormatException ex) {
            return datestring;
        }
        datestring = datestring.substring(0, idx);

        idx = datestring.indexOf('y');
        if (idx > -1) {
            year = Integer.parseInt(datestring.substring(idx + 1));
            datestring = datestring.substring(0, idx);
        }

        idx = datestring.indexOf('m');
        if (idx > -1) {
            month = Integer.parseInt(datestring.substring(idx + 1));
            datestring = datestring.substring(0, idx);
        }

        idx = datestring.indexOf('d');
        if (idx > -1) {
            day = Integer.parseInt(datestring.substring(idx + 1));
        }

        calendar.setTime(new Date());
        calendar.add(Calendar.MONTH, month);
        calendar.add(Calendar.YEAR, year);
        calendar.add(Calendar.HOUR, day * 24);
        sdf.applyPattern(liDateFormats.get(format));
        return sdf.format(calendar.getTime());
    }
}
