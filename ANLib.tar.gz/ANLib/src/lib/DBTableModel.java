/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.AbstractTableModel;

/**
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class DBTableModel extends AbstractTableModel {

    private static final Logger logger = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    private Object[] recordItems = null;
    private Vector<Object> cache = null;
    private String[] columnFields = null;
    private Vector<Object> editFields = null;
    private Vector<Object> renderFields = null;
    private Vector<String> longestField = null;
    private Vector<HashString> associatedHash = null;
    private String stringTemp = null;
    private Object objectTemp = null;
    private HashString hashTemp = null;
    private ResultSet ourRs = null;
    private ResultSetMetaData ourMeta = null;
    private SimpleDateFormat sdf = null;
    private String strPrimKey = null;
    private String strSecKey = null;
    private int primFieldCol;
    private String dateFormat = "MM/dd/yyyy";
    private String timeFormat = "HH:mm:ss";

    /**
     * Creates a new instance of DBTableModel
     */
    public DBTableModel() {
        //      String record[] = {"No Data", "No Data", "No Data", "No Data"};
        //      String names[] = {"Item1", "Item2", "Item3", "Item4"};
        //      setColumnHeader(names);
        //     cache.addElement(record);
        sdf = new SimpleDateFormat();
    }

    /**
     * Clears the tablemodel
     */
    public void reset() {
        columnFields = null;
        cache = new Vector<>(0);
        editFields = new Vector<>(0);
        renderFields = new Vector<>(0);
        longestField = new Vector<>(0);
        associatedHash = new Vector<>(0);
        // Our model has changed so fire of a changed event
        fireTableChanged(null);
    }

    /**
     * Set the column header text for a given column
     *
     * @param col
     * @param text
     */
    public void setColumnHeader(int col, String text) {
        columnFields[col] = text;
    }

    /**
     * Set all column headers from a String[]
     *
     * @param text
     */
    private void setColumnHeader(String[] text) {
        reset();
        columnFields = text;
        for (String s : text) {
            editFields.addElement(null);
            renderFields.addElement(null);
            longestField.addElement(s);
            associatedHash.addElement(null);
        }
    }

    /**
     * Set the date formatting pattern
     *
     * @param pattern
     */
    public void setDateFormat(String pattern) {
        dateFormat = pattern;
    }

    /**
     * Set the time formatting pattern
     *
     * @param pattern
     */
    public void setTimeFormat(String pattern) {
        timeFormat = pattern;
    }

    /**
     * Get the date formatting pattern as a String
     *
     * @return String
     */
    public String getDateFormat() {
        return dateFormat;
    }

    /**
     * Get the time formatting pattern as a String
     *
     * @return String
     */
    public String getTimeFormat() {
        return timeFormat;
    }

    /**
     * Sets the primary key field as the given name
     *
     * @param name
     */
    public void setPrimaryKey(String name) {
        strPrimKey = name;
        primFieldCol = findColumn(name);
    }

    /**
     * Get the primary key name
     *
     * @return name as String
     */
    public String getPrimaryKey() {
        return strPrimKey;
    }

    /**
     * Sets the secondary key field as the given name
     *
     * @param name
     */
    public void setSecondaryKey(String name) {
        strSecKey = name;
    }

    /**
     * Get the secondary key name
     *
     * @return name as String
     */
    public String getSecondaryKey() {
        return strSecKey;
    }

    /**
     * Returns the column name as a String for given column
     *
     * @param column
     * @return String
     */
    @Override
    public String getColumnName(int column) {
        return columnFields[column];
    }

    /**
     * Return the total number of columns stored within this TableModel as an
     * int
     *
     * @return int
     */
    @Override
    public int getColumnCount() {
        if (columnFields == null) {
            return 0;
        }
        return columnFields.length;
    }

    /**
     * Returns the total number of rows stored within this TableModel as an int
     *
     * @return int
     */
    @Override
    public int getRowCount() {
        if (cache == null) {
            return 0;
        }
        return cache.size();
    }

    /**
     * Returns the Object at a given row,col within the TableModel
     *
     * @param row
     * @param col
     * @return Object
     */
    @Override
    public Object getValueAt(int row, int col) {

        return ((Object[]) cache.elementAt(row))[col];
    }

    /**
     * Sets an Object value at given row and col within the table and database
     *
     * @param value
     * @param row
     * @param col
     */
    @Override
    public void setValueAt(Object value, int row, int col) {

        ((Object[]) cache.elementAt(row))[col] = value;
        objectTemp = editFields.elementAt(col);
        if (objectTemp instanceof ComboBoxEditor) {
            hashTemp = associatedHash.elementAt(col);
            value = ((ComboBoxEditor) objectTemp).getSelectedItem();
            value = hashTemp.getKey((String) value);
        }
        updateDB(value.toString(), row, col);
        fireTableCellUpdated(row, col);
    }

    /**
     * Returns whether the cell at row and col is editable or not
     *
     * @param row
     * @param col
     * @return boolean
     */
    @Override
    public boolean isCellEditable(int row, int col) {
        return getCellEditorAt(col) != null;
    }

    /**
     * Finds a column index from its name, case insensitive
     *
     * @param columnName
     * @return int
     */
    @Override
    public int findColumn(String columnName) {
        for (int i = 0; i < getColumnCount(); i++) {
            if (getColumnName(i).compareToIgnoreCase(columnName) == 0) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Get column class at the given column
     *
     * @param column
     * @return class
     */
    @Override
    public Class<?> getColumnClass(int column) {

        try {
            objectTemp = ((Object[]) cache.elementAt(0))[column];
            return objectTemp.getClass();
        } catch (Exception ex) {
            // This prevents an error on tablesorter when their are no table results
            return String.class;
        }
    }

    /**
     * Returns the cell editor for the given column
     *
     * @param column
     * @return Object
     */
    public Object getCellEditorAt(int column) {
        return editFields.elementAt(column);
    }

    /**
     * Set up a combo editor on a column
     *
     * @param aComboEditor
     * @param col
     */
    public void setComboEditorAt(ComboBoxEditor aComboEditor, int col) {
        editFields.setElementAt(aComboEditor, col);
    }

    /**
     * Set up a text editor on a column
     *
     * @param col
     */
    public void setTextEditorAt(int col) {
        editFields.setElementAt("", col);
    }

    /**
     * Set up a ComboBox renderer on a column
     *
     * @param aComboRenderer
     * @param col
     */
    public void setRenderer(ComboBoxRenderer aComboRenderer, int col) {
        renderFields.setElementAt(aComboRenderer, col);
    }

    /**
     * Set up a numeric to text renderer on a column with given values
     *
     * @param col
     * @param values
     */
    public void setRenderer(int col, String[] values) {
        renderFields.setElementAt(values, col);
    }

    /**
     * Get renderer being used on specified column
     *
     * @param col
     * @return Object
     */
    public Object getCellRendererAt(int col) {
        return renderFields.elementAt(col);
    }

    /**
     * Set associated HashString on a given column
     *
     * @param col
     * @param revHs
     */
    public void setAssociatedHash(int col, HashString revHs) {
        associatedHash.setElementAt(revHs, col);
    }

    /**
     * Update a single value at row and col within the database
     *
     * @param value
     * @param row
     * @param col
     */
    private void updateDB(String value, int row, int col) {

        String query;
        String table;
        String uidname;
        String uid;
        String fieldname;
        String catalog;

        // Verify we have a result set
        if (ourRs == null) {
            System.out.println("Result set not found");
            return;
        }
        // We need to get the primary key value first
        if (primFieldCol == -1) {
            System.out.println("Please set the primary field column");
        }
        String keyvalue = getValueAt(row, primFieldCol).toString();
        try {
            // We need to find the correct row in the resultset
            // We do this by searching on the primary key
            // Please remember resultset rows and cols begin at 1 and not zero
            col++;
            ourRs.first();
            while (ourRs.getString(primFieldCol + 1).compareTo(keyvalue) != 0) {
                ourRs.next();
            }
            uidname = getSecondaryKey();
            if (uidname == null) {
                uidname = ourRs.getMetaData().getColumnName(primFieldCol + 1);
            }
            fieldname = ourRs.getMetaData().getColumnName(col);
            table = ourRs.getMetaData().getTableName(col);
            uid = ourRs.getString(primFieldCol + 1);
            query = "UPDATE " + table + " SET " + fieldname + "='" + value + "' WHERE " + uidname + "='" + uid + "'";
            catalog = ourRs.getMetaData().getCatalogName(col);
            // Need to be carefull to use a new statement so we dont destroy our resultset
            ourRs.getStatement().getConnection().createStatement().executeUpdate("USE " + catalog);
            ourRs.getStatement().getConnection().createStatement().executeUpdate(query);
            logger.log(Level.INFO, "updateDB {0}", query);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "updateResultSet", ex);
        }
    }

    /**
     * Adds a new record of values to the table and database
     *
     * @param values
     * @throws Exception
     */
    public void addNewRecord(String... values) throws Exception {

        // Verify we have a result set
        if (ourRs == null) {
            System.out.println("Result set not found");
            return;
        }

        // We need to get the primary key value first
        if (primFieldCol == -1) {
            System.out.println("Please set the primary field column");
            return;
        }

        if (isDrizzle()) {
            addNewRecordDrizzle(values);
            return;
        }

        int i = 0;
        int x = 0;
        ourRs.moveToInsertRow();
        while (x < values.length) {
            if (i == primFieldCol) {
                i++;
            }
            ourRs.updateString(getColumnName(i++), values[x++]);
        }
        ourRs.insertRow();
        ourRs.moveToCurrentRow();
        ourRs.previous();
        refreshTableContents();
    }

    /**
     * Adds a new record of values to the table and database. For Drizzle driver
     * only.
     *
     * @param values
     * @throws Exception
     */
    private void addNewRecordDrizzle(String... values) throws Exception {
        String query;
        query = createSingleInsert(ourRs, values);
        // Need to be carefull to use a new statement so we dont destroy our resultset
        ourRs.getStatement().getConnection().createStatement().executeUpdate("USE " + ourRs.getMetaData().getCatalogName(1));
        ourRs.getStatement().getConnection().createStatement().executeUpdate(query);
    }

    /**
     * Insert values into a resultset, will return resultant insert as string if
     * successful or a null string if failed
     *
     * @param rs
     * @param values
     * @return String
     */
    private String createSingleInsert(ResultSet rs, String... values) {
        String insertValues;
        String colnames = "";
        String valdelim = "";
        String temp;

        try {
            // Get data values from each column and format result based on column type
            for (int i = 0; i < values.length; i++) {
                colnames += valdelim + rs.getMetaData().getColumnName(i + 2);
                valdelim = ",";
            }
            colnames = "INSERT INTO `" + rs.getMetaData().getTableName(1) + "` (" + colnames + ") values (";

            valdelim = insertValues = "";
            for (int i = 0; i < values.length; i++) {
                switch (rs.getMetaData().getColumnType(i + 2)) {
                    case java.sql.Types.BIGINT:
                    case java.sql.Types.BINARY:
                    case java.sql.Types.DOUBLE:
                    case java.sql.Types.FLOAT:
                    case java.sql.Types.INTEGER:
                    case java.sql.Types.REAL:
                    case java.sql.Types.NUMERIC:
                    case java.sql.Types.SMALLINT:
                    case java.sql.Types.TINYINT:
                        temp = values[i];
                        insertValues += (valdelim + temp);
                        break;

                    case java.sql.Types.TIMESTAMP:
                        try {
                            temp = values[i];
                        } catch (Exception e) {
                            temp = "0000-00-00 00:00:00";
                        }
                        if (temp == null) {
                            insertValues += (valdelim + "null");
                        } else {
                            insertValues += (valdelim + "'" + temp + "'");
                        }
                        break;

                    default:
                        temp = values[i];
                        if (temp != null) {
                            temp = temp.replaceAll("[']", "\\\\'");
                            temp = temp.replaceAll("[\n]", "\\\\n");
                            temp = temp.replaceAll("[\r]", "\\\\r");
                            insertValues += (valdelim + "'" + temp + "'");
                        } else {
                            insertValues += (valdelim + temp);
                        }
                        break;
                } // End of Switch
                valdelim = ",";
            } // End of For
            return colnames + insertValues + ")";
        } catch (Exception ex) {
            return null;
        }
    }

    /**
     * Deletes selected records from the table and database, returns id's
     * contained in the specified column
     *
     * @param aTable
     * @return String[]
     */
    public String[] deleteRecords(DBJTableBean aTable) {

        if (primFieldCol == -1) {
            System.out.println("Please set the primary field column");
        }
        String keyvalue;
        int[] selRows = aTable.getSelectedRows();
        String id[] = new String[selRows.length];
        try {
            for (int i = 0; i < selRows.length; i++) {
                ourRs.first();
                id[i] = keyvalue = aTable.getValueAt(selRows[i], primFieldCol).toString();
                while (ourRs.getString(primFieldCol + 1).compareToIgnoreCase(keyvalue) != 0) {
                    ourRs.next();
                }
                if (isDrizzle()) {
                    deleteRowDrizzle();
                } else {
                    ourRs.deleteRow();
                }
            }
            cache = new Vector<>(0);
            ourRs.beforeFirst();
            refreshTableContents();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "deleteRecords(DBJTableBean aTable)", ex);
        }
        return id;
    }

    /**
     * Delete row using drizzle driver
     */
    private void deleteRowDrizzle() {
        String query;
        String table;
        String uidname;
        String uid;
        String catalog;
        try {
            uidname = ourRs.getMetaData().getColumnName(primFieldCol + 1);
            table = ourRs.getMetaData().getTableName(primFieldCol + 1);
            uid = ourRs.getString(primFieldCol + 1);
            query = "DELETE FROM " + table + " WHERE " + uidname + "='" + uid + "'";
            catalog = ourRs.getMetaData().getCatalogName(primFieldCol + 1);
            // Need to be carefull to use a new statement so we dont destroy our resultset
            ourRs.getStatement().getConnection().createStatement().executeUpdate("USE " + catalog);
            ourRs.getStatement().getConnection().createStatement().executeUpdate(query);
            logger.log(Level.INFO, "deleteRowDrizzle() {0}", query);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "deleteRowDrizzle()", ex);
        }
    }

    /**
     * Set the resultset from which the table will be populated
     *
     * @param rs The resultset from a query
     */
    public void setResultSet(ResultSet rs) {
        setResultSet(rs, null);
    }

    /**
     * Set the resultset from which the table will be populated with headers
     * override
     *
     * @param rs
     * @param headers
     */
    public void setResultSet(ResultSet rs, String[] headers) {
        try {
            ourRs = rs;
            ourMeta = rs.getMetaData();
            if (headers == null) {
                headers = new String[ourMeta.getColumnCount()];
                for (int i = 0; i < ourMeta.getColumnCount(); i++) {
                    headers[i] = ourMeta.getColumnLabel(i + 1);
                }
            }
            setColumnHeader(headers);
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "setResultSet", ex);
        }
    }

    /**
     * Refreshes the table contents and fires the changed event
     */
    public void refreshTableContents() {
        boolean changed = false;
        int colcount = 0;
        String key;
        String strMetric = "";

        if (ourRs == null) {
            return;
        }

        try {
            colcount = getColumnCount();
            if (ourRs.isClosed()) {
                emptyTableFix(colcount);
                return;
            }

            while (ourRs.next()) {
                changed = true;
                recordItems = new Object[colcount];
                for (int col = 0; col < colcount; col++) {

                    // Get our object for this column from resultset, check for null
                    try {
                        objectTemp = ourRs.getObject(col + 1);
                    } catch (SQLException sex) {
                        objectTemp = null;
                    }
                    if (objectTemp != null) {
                        // Handle date and time formatting here
                        switch (ourMeta.getColumnType(col + 1)) {
                            case java.sql.Types.TIMESTAMP:
                                sdf.applyPattern(dateFormat + " " + timeFormat);
                                objectTemp = sdf.format(objectTemp);
                                break;
                            case java.sql.Types.DATE:
                                sdf.applyPattern(dateFormat);
                                objectTemp = sdf.format(objectTemp);
                                break;
                            case java.sql.Types.TIME:
                                sdf.applyPattern(timeFormat);
                                objectTemp = sdf.format(objectTemp);
                                break;
                        }
                    } else {
                        objectTemp = "NULL";
                    }

                    hashTemp = associatedHash.elementAt(col);
                    if (hashTemp != null) {
                        key = objectTemp.toString();
                        objectTemp = hashTemp.get(key);
                        strMetric = hashTemp.getLongestValue();
                        if (objectTemp == null) {
                            hashTemp.putStringValue(key, key);
                            objectTemp = getCellRendererAt(col);
                            if (objectTemp instanceof ComboBoxRenderer) {
                                ((ComboBoxRenderer) objectTemp).addItem(key);
                            }
                            objectTemp = key;
                        }
                    }

                    // Convert all to string for string measurement
                    stringTemp = objectTemp.toString();
                    if (strMetric.isEmpty()) {
                        strMetric = stringTemp;
                    }
                    if (strMetric.length() > longestField.elementAt(col).length()) {
                        longestField.setElementAt(strMetric, col);
                    }
                    strMetric = "";
                    recordItems[col] = objectTemp;
                } // End of for
                cache.addElement(recordItems);
            }
            ourRs.beforeFirst();
        } catch (Exception ex) {
            logger.throwing(this.getClass().getName(), "refreshTableContents()", ex);
        }

        // This is a fix for empty table results
        if (!changed) {
            emptyTableFix(colcount);
        }
        // Our table has changed so fire of a changed event
        fireTableChanged(null);
    }

    /**
     * Returns true if we are using the Drizzle sql driver
     *
     * @return boolean
     */
    private boolean isDrizzle() {
        try {
            return ourRs.getStatement().getConnection().getClass().getCanonicalName().contains("Drizzle");
        } catch (SQLException ex) {
            return false;
        }
    }

    /**
     * A Fix for an empty table. Not exactly sure why i needed this.
     *
     * @param colcount
     */
    private void emptyTableFix(int colcount) {
        recordItems = new Object[colcount];
        for (int col = 0; col < colcount; col++) {
            recordItems[col] = "";
        }
        cache.addElement(recordItems);
        fireTableChanged(null);
        cache = new Vector<>(0);
    }

    /**
     * Returns the longest string within a column
     *
     * @param column
     * @return String
     */
    public String getLongestString(int column) {
        return longestField.elementAt(column);
    }

    /**
     * Tests for an existing string in a database column
     *
     * @param text
     * @param column
     * @return boolean
     */
    public boolean getStringExists(String text, int column) {

        if (column < 0) {
            return false;
        }
        String name;
        for (int i = 0; i < cache.size(); i++) {
            name = (String) ((Object[]) (cache.elementAt(i)))[column];
            if (name.compareToIgnoreCase(text) == 0) {
                return true;
            }
        }
        return false;
    }
}
