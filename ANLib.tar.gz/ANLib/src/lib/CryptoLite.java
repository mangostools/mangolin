/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.math.BigInteger;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.zip.CRC32;
import java.util.zip.Checksum;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class CryptoLite {

    private static final String SPHRASE = "sdgmbl[]]p665754sdij12";

    public CryptoLite() {
    }

    public PublicKey getPublicFromEncoded(byte[] encoded, String alg) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance(alg);
        X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(encoded);
        return keyFactory.generatePublic(pubKeySpec);
    }

    public PrivateKey getPrivateFromEncoded(byte[] encoded, String alg) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance(alg);
        X509EncodedKeySpec privKeySpec = new X509EncodedKeySpec(encoded);
        return keyFactory.generatePrivate(privKeySpec);
    }

    public String EncryptMD5(String text) {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException ex) {
            return null;
        }
        md.update(text.getBytes(), 0, text.length());
        return new BigInteger(1, md.digest()).toString(16);
    }

    public String encryptPassword(char[] pass, String keyphrase) {

        String strPass = new String(pass);
        try {
            keyphrase += SPHRASE;
            SecretKey sk = genSecretDesede(keyphrase.getBytes());
            return bytesToHexString(encrypt(strPass.getBytes(), sk, "DESede"));
        } catch (Exception ex) {
            return null;
        }
    }

    public String decryptPassword(String text, String keyphrase) {

        try {
            keyphrase += SPHRASE;
            SecretKey sk = genSecretDesede(keyphrase.getBytes());
            return new String(decrypt(hexStringToBytes(text), sk, "DESede"));
        } catch (Exception ex) {
            return null;
        }
    }

    public SecretKey genSecretAes(byte[] phrase) throws Exception {
        byte reducedkey[] = new byte[16];
        int cntr = 0;
        for (int idx = 0; idx < phrase.length; idx++) {
            reducedkey[cntr] ^= phrase[idx];
            if (++cntr == reducedkey.length) {
                cntr = 0;
            }
        }
        return new SecretKeySpec(reducedkey, "AES");
    }

    public SecretKey genSecretDesede(byte[] phrase) throws Exception {
        byte reducedkey[] = new byte[24];
        int cntr = 0;
        for (int idx = 0; idx < phrase.length; idx++) {
            reducedkey[cntr] ^= phrase[idx];
            if (++cntr == reducedkey.length) {
                cntr = 0;
            }
        }
        return new SecretKeySpec(reducedkey, "DESede");
    }

    public KeyPair genKeyPair(String alg, int keysize) throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance(alg);
        kpg.initialize(keysize);
        return kpg.generateKeyPair();
    }

    public byte[] encrypt(byte[] inpBytes, SecretKey key, String alg) throws Exception {

        Cipher cipher = Cipher.getInstance(alg);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(inpBytes);
    }

    public byte[] decrypt(byte[] inpBytes, SecretKey key, String alg) throws Exception {

        Cipher cipher = Cipher.getInstance(alg);
        cipher.init(Cipher.DECRYPT_MODE, key);
        return cipher.doFinal(inpBytes);
    }

    public void saveEncodedKey(String filename, byte[] encodedKey) throws Exception {
        SimpleFileIO myFileIo = new SimpleFileIO();
        myFileIo.setWriteFilename(filename);
        myFileIo.openBufferedWrite();
        myFileIo.writeToFile(bytesToHexString(encodedKey), 0);
        myFileIo.closeBufferedWrite();
    }

    public byte[] loadEncodedKey(String filename) throws Exception {
        String text;
        SimpleFileIO myFileIo = new SimpleFileIO();
        myFileIo.setReadFilename(filename);
        myFileIo.openBufferedRead();
        text = myFileIo.readEntireFile();
        myFileIo.closeBufferedRead();
        return hexStringToBytes(text);
    }

    public String bytesToHexString(byte[] b) throws Exception {
        String result = "";
        for (int i = 0; i < b.length; i++) {
            result += Integer.toString((b[i] & 0xff) + 0x100, 16).substring(1);
        }
        return result;
    }

    public byte[] hexStringToBytes(String hexstring) throws Exception {
        byte[] result = new byte[hexstring.length() / 2];
        int x = 0;
        for (int i = 0; i < hexstring.length(); i += 2) {
            result[i / 2] = (byte) ((Character.digit(hexstring.charAt(i), 16) << 4) + Character.digit(hexstring.charAt(i + 1), 16));
        }
        return result;
    }

    public String getSecretKey(String text, int start, int chars) {
        int txtLen = text.length();
        String strResult;
        if (start > txtLen - 1) {
            start = 0;
            chars = txtLen;
        }
        if (start + chars > txtLen) {
            chars = txtLen - start;
        }
        strResult = text.substring(start, start + chars).replace(" ", "_");
        strResult = strResult.replace("\n", "nl");
        return strResult;
    }

    public SecretKey generateKey(String... data) {

        SecretKey secKey;
        String strSeed = "";
        try {
            for (String s : data) {
                strSeed += s;
            }
            secKey = genSecretAes(strSeed.getBytes());
            return secKey;
        } catch (Exception ex) {
            return null;
        }
    }

    public String getChecksum(String text) {
        Checksum check = new CRC32();
        byte[] b = text.getBytes();
        check.update(b, 0, b.length);
        return String.valueOf(check.getValue());
    }
}
