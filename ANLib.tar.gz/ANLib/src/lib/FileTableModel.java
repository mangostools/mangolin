/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.io.File;
import java.io.FileFilter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.table.AbstractTableModel;

/**
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class FileTableModel extends AbstractTableModel {

    private File myFile = null;
    private String[] colNames = {"Filename", "Last Modified"};
    private File[] fileList = null;
    private String myFilter = "";
    private Vector<Object> cache = new Vector<>(0);
    private String[] record;
    private SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

    /**
     * Creates a new instance of FileTableModel
     */
    public FileTableModel() {
        setDateFormat("MM/dd/yyyy HH:mm:ss");
    }

    /**
     * Returns the date formatter
     *
     * @return Returns the date formatter
     */
    public SimpleDateFormat getDateFormat() {
        return formatter;
    }

    /**
     * Sets the date format
     *
     * @param format
     */
    public final void setDateFormat(String format) {
        formatter = new SimpleDateFormat(format);
    }

    /**
     * Returns the column name as a String at the given column
     *
     * @param column
     * @return String
     */
    @Override
    public String getColumnName(int column) {
        if (fileList == null) {
            return null;
        }
        return colNames[column];
    }

    /**
     * Returns the current file list
     *
     * @return File[]
     */
    public File[] getFileList() {
        return fileList;
    }

    /**
     * Return the total number of columns stored within this TableModel
     *
     * @return int
     */
    @Override
    public int getColumnCount() {
        if (fileList == null) {
            return 0;
        }
        return colNames.length;
    }

    /**
     * Returns the total number of rows stored within this TableModel
     *
     * @return int
     */
    @Override
    public int getRowCount() {
        if (fileList == null) {
            return 0;
        }
        return fileList.length;
    }

    /**
     * Returns the Object at a given row,col within the TableModel
     *
     * @param row
     * @param col
     * @return Object
     */
    @Override
    public Object getValueAt(int row, int col) {
        return ((String[]) (cache.get(row)))[col];
    }

    /**
     * Returns the currently selected File object within the table
     *
     * @param aTable
     * @return File
     */
    public File getSelectedFile(JTable aTable) {
        RowSorter sort = aTable.getRowSorter();
        int row = sort.convertRowIndexToModel(aTable.getSelectedRow());
        return fileList[row];
    }

    /**
     * Sets the filepath
     *
     * @param filepath
     */
    public void setFilePath(String filepath) {
        myFile = new File(filepath);
    }

    /**
     * creates a folder
     *
     */
    public void createFolder() {
        try {
            myFile.mkdir();
        } catch (Exception ex) {
        }
    }

    /**
     * Sets the file filter
     *
     * @param filter
     */
    public void setFileFilter(String filter) {
        myFilter = filter;
    }

    /**
     * Refreshes the file list based on filter contents
     */
    public void refreshFileList() {

        fileList = myFile.listFiles();
        if (myFilter.isEmpty()) {
            fileList = myFile.listFiles();
        } else {
            fileList = myFile.listFiles(new FileFilter() {

                @Override
                public boolean accept(File pathname) {
                    if (pathname.getPath().contains(myFilter)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            });
        }
    }

    /**
     * Refreshes the table
     */
    public void refreshTable() {
        cache = new Vector<>(0);
        if (fileList != null) {
            for (int i = 0; i < fileList.length; i++) {
                record = new String[2];
                record[0] = fileList[i].getName();
                record[1] = formatter.format(new Date(fileList[i].lastModified()));
                cache.add(record);
            }
        }
        // Our table has changed so fire of a changed event
        fireTableChanged(null);
    }

    /**
     * Deletes selected files within the given table
     *
     * @param aTable
     */
    public void deleteRecords(JTable aTable) {

        RowSorter sorter = aTable.getRowSorter();
        int[] selRows = aTable.getSelectedRows();
        for (int i = 0; i < selRows.length; i++) {
            fileList[sorter.convertRowIndexToModel(selRows[i])].delete();
        }
    }
}
