/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 *
 * @author Alistair Neil, <info@dazzleships.net>
 */
public class WinReg {

    static final String HEXES = "0123456789ABCDEF";

    public WinReg() {
    }

    /**
     * Export a key to a file, returns true if successful
     *
     * @param keyname
     * @param filename
     * @return boolean
     */
    public boolean exportToFile(String keyname, String filename) {
        ArrayList<String> al = invokeReg("export " + withQuotes(keyname) + " " + withQuotes(filename));
        if (al == null || al.isEmpty()) {
            return false;
        }
        return al.get(al.size() - 1).contains("completed successfully");
    }

    /**
     * Import a key from a file, returns true if successful
     *
     * @param filename
     * @return boolean
     */
    public boolean importFromFile(String filename) {
        ArrayList<String> al = invokeReg("import " + withQuotes(filename));
        if (al == null || al.isEmpty()) {
            return false;
        }
        return al.get(al.size() - 1).contains("completed successfully");
    }

    /**
     * Write a string value to key.valuename
     *
     * @param key
     * @param valuename
     * @param value
     */
    public void writeString(String key, String valuename, String value) {
        writeKeyValue(key, valuename, value, "REG_SZ");
    }

    /**
     * Read a string value from key.valuename
     *
     * @param key
     * @param valuename
     * @return String
     */
    public String readString(String key, String valuename) {
        return readKeyValue(key, valuename, "REG_SZ");
    }

    /**
     * Read a binary value from key.valuename
     *
     * @param key
     * @param valuename
     * @return byte array
     */
    public byte[] readBinary(String key, String valuename) {
        String result = readKeyValue(key, valuename, "REG_BINARY");
        if (result != null) {
            return hexStringToBytes(result);
        }
        return null;
    }

    /**
     * Read a long dword value from key.valuename
     *
     * @param key
     * @param valuename
     * @return long
     */
    public long readDWord(String key, String valuename) {
        String result = readKeyValue(key, valuename, "REG_DWORD");
        return Long.decode(result).longValue();
    }

    /**
     * Write a dword value to key.valuename
     *
     * @param key
     * @param valuename
     * @param value
     */
    public void writeDWord(String key, String valuename, long value) {
        writeKeyValue(key, valuename, String.valueOf(value), "REG_DWORD");
    }

    /**
     * Write a binary value to key.valuename
     *
     * @param key
     * @param valuename
     * @param bytes
     */
    public void writeBinary(String key, String valuename, byte[] bytes) {
        writeKeyValue(key, valuename, bytesToHexString(bytes), "REG_BINARY");
    }

    /**
     * Generic readKey from key.valuename of type where type can be the
     * following string values REG_DWORD, REG_BINARY or REG_SZ
     *
     * @param key
     * @param valuename
     * @param type
     * @return String
     */
    private String readKeyValue(String key, String valuename, String type) {

        Pattern pattern = Pattern.compile("    ");
        // This will cause the default/empty value of a key to be returned
        if (valuename == null) {
            valuename = "";
        }
        ArrayList<String> list = invokeReg("query "
                + withQuotes(key) + " /v "
                + withQuotes(valuename));
        if (list.isEmpty()) {
            return null;
        }
        if (list.get(0).startsWith("!")) {
            list.remove(0);
            pattern = Pattern.compile("\t");
        }
        list.remove(0);
        // If list is empty then nothing was returned
        if (list.isEmpty()) {
            return null;
        }

        // Split separated values
        String[] temp = pattern.split(list.get(0).trim());
        // Check to ensure data type is consistent with a string.
        if (temp[1].contentEquals(type)) {
            return temp[2];
        }
        return null;
    }

    /**
     * Read subkeys from key as a list of strings.
     *
     * @param key
     * @return ArrayList<String>
     */
    public ArrayList<String> readSubKeys(String key) {
        Pattern pattern = Pattern.compile("    ");
        String[] temp;
        ArrayList<String> result = new ArrayList<>();
        ArrayList<String> list = invokeReg("query "
                + withQuotes(key));
        // If list is empty then nothing was returned
        if (list.isEmpty()) {
            return result;
        }
        if (list.get(0).startsWith("!")) {
            list.remove(0);
            pattern = Pattern.compile("\t");
        }
        list.remove(0);
        // If list is empty then nothing was returned
        if (list.isEmpty()) {
            return result;
        }
        for (String s : list) {
            s = s.trim();
            // Split tab separated values
            temp = pattern.split(s);
            if (temp.length == 1) {
                result.add(replaceWithShortMachineNames(s));
            }
        }
        return result;
    }

    /**
     * Read subvalues as a list of strings from valuename
     *
     * @param valuename
     * @return ArrayList<String>
     */
    public ArrayList<String> readSubValues(String valuename) {
        Pattern pattern = Pattern.compile("    ");
        String[] temp;
        ArrayList<String> result = new ArrayList<>();
        ArrayList<String> list = invokeReg("query "
                + withQuotes(valuename));
        // If list is empty then nothing was returned
        if (list.isEmpty()) {
            return result;
        }
        if (list.get(0).startsWith("!")) {
            list.remove(0);
            pattern = Pattern.compile("\t");
        }
        list.remove(0);
        // If list is empty then nothing was returned
        if (list.isEmpty()) {
            return result;
        }
        for (String s : list) {
            s = s.trim();
            // Split tab separated values
            temp = pattern.split(s);
            if (temp.length == 3) {
                result.add(replaceWithShortMachineNames(s));
            }
        }
        return result;
    }

    /**
     * Write value of type to keyname>valuename
     *
     * @param keyname
     * @param valuename
     * @param value
     * @param type
     */
    private void writeKeyValue(String keyname, String valuename, String value, String type) {
        invokeReg("add " + withQuotes(keyname)
                + " /v " + withQuotes(valuename)
                + " /t " + type + " /d "
                + withQuotes(value) + " /f");
    }

    /**
     * Delete keyname>valuename
     *
     * @param keyname
     * @param valuename
     */
    public void deleteKeyValue(String keyname, String valuename) {
        invokeReg("delete " + withQuotes(keyname)
                + " /v " + withQuotes(valuename) + " /f");
    }

    /**
     * Delete keyname
     *
     * @param keyname
     */
    public void deleteKey(String keyname) {
        invokeReg("delete " + withQuotes(keyname) + " /f");
    }

    /**
     * Replace long machine names with short machine names
     *
     * @param s
     * @return String containing short machine names
     */
    private String replaceWithShortMachineNames(String s) {
        s = s.replace("HKEY_LOCAL_MACHINE", "HKLM");
        s = s.replace("HKEY_CURRENT_USER", "HKCU");
        s = s.replace("HKEY_USERS", "HKU");
        s = s.replace("HKEY_CURRENT_CONFIG", "HKCC");
        s = s.replace("HKEY_CLASSES_ROOT", "HKCR");
        return s;
    }

    /**
     * Place quotes around a value, returns the original string with quotes inserted.
     *
     * @param value
     * @return String
     */
    private String withQuotes(String value) {
        return "\"" + value + "\"";
    }

    /**
     * Convert a byte array to a hex string
     *
     * @param raw
     * @return String in hex format
     */
    public String bytesToHexString(byte[] raw) {
        if (raw == null) {
            return null;
        }
        final StringBuilder hex = new StringBuilder(2 * raw.length);
        for (final byte b : raw) {
            hex.append(HEXES.charAt((b & 0xF0) >> 4)).append(HEXES.charAt((b & 0x0F)));
        }
        return hex.toString();
    }

    /**
     * Convert a hex string to a byte array
     *
     * @param hexdata
     * @return byte[]
     */
    private byte[] hexStringToBytes(String hexdata) {
        String temp;
        byte[] bytes = new byte[hexdata.length() / 2];
        int z = 0;
        for (int i = 0; i < hexdata.length(); i += 2) {
            temp = "0x" + hexdata.substring(i, i + 2);
            bytes[z++] = Integer.decode(temp).byteValue();
        }
        return bytes;
    }

    /**
     * Run windows CLI registry application with the given arguments
     *
     * @param arg
     * @return ArrayList
     */
    private ArrayList<String> invokeReg(String arguments) {
        try {
            return getProcessResults(Runtime.getRuntime().exec("reg " + arguments));
        } catch (Exception ex) {
        }
        return null;
    }

    /**
     * Get results as a list of strings from a runtime process
     *
     * @param aprocess
     * @return ArrayList<String>
     */
    private ArrayList<String> getProcessResults(Process aprocess) {

        String line;
        BufferedReader input;
        ArrayList<String> arrList = new ArrayList<>();

        try {
            input = new BufferedReader(new InputStreamReader(aprocess.getInputStream()));
            while ((line = input.readLine()) != null) {
                if (line.isEmpty()) {
                    continue;
                }
                arrList.add(line);
            }
            input.close();
            return arrList;
        } catch (Exception ex) {
        }
        return null;
    }
}
