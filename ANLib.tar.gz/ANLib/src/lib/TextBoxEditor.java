/*
 * Copyright (C) 2007-2013 Alistair Neil, <info@dazzleships.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License Version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package lib;

import java.awt.Font;
import javax.swing.DefaultCellEditor;
import javax.swing.JTextField;

/**
 * @author Alistair Neil, <info@dazzleships.net>
 */
public final class TextBoxEditor extends DefaultCellEditor {

    /**
     * Creates a new instance of TextBoxEditor
     * @param value
     */
    public TextBoxEditor(String value) {
        super(new JTextField(value));
    }

    /**
     * Sets the font of this editor component
     * @param afont
     */
    public void setFont(Font afont) {
        editorComponent.setFont(afont);
    }
}
